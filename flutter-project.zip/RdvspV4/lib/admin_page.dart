import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['vip', 'reseller', 'reseller1', 'owner', 'member'];
  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 25;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://haikal.privatenusantara.my.id:2301/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showDialog("⚠️ Error", data['message'] ?? 'Tidak diizinkan melihat daftar user.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Gagal memuat user list.");
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  List<dynamic> _getCurrentPageData() {
    final start = (currentPage - 1) * itemsPerPage;
    final end = (start + itemsPerPage);
    return filteredList.sublist(start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages => (filteredList.length / itemsPerPage).ceil();

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _showDialog("⚠️ Error", "Masukkan username yang ingin dihapus.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse('http://haikal.privatenusantara.my.id:2301/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _showDialog("✅ Berhasil", "User '${data['user']['username']}' telah dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Tidak dapat menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final username = createUsernameController.text.trim();
    final password = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (username.isEmpty || password.isEmpty || day.isEmpty) {
      _showDialog("⚠️ Error", "Semua field wajib diisi.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://haikal.privatenusantara.my.id:2301/userAdd?key=$sessionKey&username=$username&password=$password&day=$day&role=$newUserRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showDialog("✅ Sukses", "Akun '${data['user']['username']}' berhasil dibuat.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        newUserRole = 'member';
        _fetchUsers();
      } else {
        _showDialog("❌ Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _showDialog("🌐 Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _showDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black,
        title: Text(title, style: const TextStyle(color: Colors.purpleAccent)),
        content: Text(message, style: const TextStyle(color: Colors.purpleAccent)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.purpleAccent)),
          )
        ],
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    return Card(
      color: Colors.grey[850],
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        title: Text(
          user['username'],
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              "Role: ${user['role']} | Exp: ${user['expiredDate']}",
              style: const TextStyle(color: Colors.white70, fontSize: 13),
            ),
            const SizedBox(height: 2),
            Text(
              "Parent: ${user['parent'] ?? 'SYSTEM'}",
              style: const TextStyle(color: Colors.deepPurpleAccent, fontSize: 12),
            ),
          ],
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.deepPurpleAccent),
          onPressed: () async {
            final confirm = await showDialog<bool>(
              context: context,
              builder: (_) => AlertDialog(
                backgroundColor: Colors.black,
                title: const Text("Konfirmasi", style: TextStyle(color: Colors.purpleAccent)),
                content: Text(
                  "Yakin ingin menghapus user '${user['username']}'?",
                  style: const TextStyle(color: Colors.purpleAccent),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text("Batal", style: TextStyle(color: Colors.white)),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text("Hapus", style: TextStyle(color: Colors.deepPurpleAccent)),
                  ),
                ],
              ),
            );

            if (confirm == true) {
              deleteController.text = user['username'];
              _deleteUser();
            }
          },
        ),
      ),
    );
  }

  Widget _buildPagination() {
    return Wrap(
      spacing: 8,
      children: List.generate(totalPages, (index) {
        final page = index + 1;
        return ElevatedButton(
          onPressed: () => setState(() => currentPage = page),
          style: ElevatedButton.styleFrom(
            backgroundColor: currentPage == page ? Colors.deepPurpleAccent : Colors.purple,
            padding: const EdgeInsets.symmetric(horizontal: 16),
          ),
          child: Text("$page", style: const TextStyle(color: Colors.white)),
        );
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Delete User
            TextField(
              controller: deleteController,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: InputDecoration(
                labelText: "Username untuk dihapus",
                labelStyle: const TextStyle(color: Colors.purpleAccent),
                enabledBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.purple),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: const BorderSide(color: Colors.deepPurpleAccent),
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: isLoading ? null : _deleteUser,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
              ),
              child: const Text("DELETE", style: TextStyle(fontFamily: 'Orbitron', color: Colors.white)),
            ),

            const SizedBox(height: 30),
            const Divider(color: Colors.purple),

            // Create Account
            const Text("Create Account", style: TextStyle(color: Colors.purpleAccent, fontSize: 18, fontFamily: 'Orbitron')),
            const SizedBox(height: 10),

            TextField(
              controller: createUsernameController,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: _inputDecoration("Username"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: createPasswordController,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: _inputDecoration("Password"),
            ),
            const SizedBox(height: 10),

            TextField(
              controller: createDayController,
              keyboardType: TextInputType.number,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: _inputDecoration("Durasi (hari)"),
            ),
            const SizedBox(height: 10),

            DropdownButtonFormField<String>(
              value: newUserRole,
              dropdownColor: Colors.black,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: _inputDecoration("Role"),
              items: roleOptions.map((role) {
                return DropdownMenuItem(value: role, child: Text(role.toUpperCase(), style: const TextStyle(color: Colors.purpleAccent)));
              }).toList(),
              onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
            ),
            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: isLoading ? null : _createAccount,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.purple,
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
              ),
              child: const Text("CREATE", style: TextStyle(fontFamily: 'Orbitron', color: Colors.white)),
            ),

            const SizedBox(height: 30),
            const Divider(color: Colors.purple),

            // Role Filter
            DropdownButtonFormField<String>(
              value: selectedRole,
              dropdownColor: Colors.black,
              style: const TextStyle(color: Colors.purpleAccent),
              decoration: _inputDecoration("Filter Role"),
              items: roleOptions.map((role) {
                return DropdownMenuItem(value: role, child: Text(role.toUpperCase(), style: const TextStyle(color: Colors.purpleAccent)));
              }).toList(),
              onChanged: (val) {
                if (val != null) {
                  selectedRole = val;
                  _filterAndPaginate();
                }
              },
            ),

            const SizedBox(height: 20),
            const Text("User List", style: TextStyle(color: Colors.purpleAccent, fontSize: 18, fontFamily: 'Orbitron')),

            isLoading
                ? const CircularProgressIndicator(color: Colors.purpleAccent)
                : Column(
              children: [
                ..._getCurrentPageData().map((u) => _buildUserItem(u)).toList(),
                const SizedBox(height: 12),
                _buildPagination(),
              ],
            ),
          ],
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      labelStyle: const TextStyle(color: Colors.purpleAccent),
      enabledBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: Colors.purple),
        borderRadius: BorderRadius.circular(12),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: const BorderSide(color: Colors.deepPurpleAccent),
        borderRadius: BorderRadius.circular(12),
      ),
    );
  }
}